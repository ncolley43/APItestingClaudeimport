import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  // API tests share setup data created in beforeAll, so keep each file in one worker
  fullyParallel: false,
  retries: 0,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    baseURL: process.env.BASE_URL ?? 'https://restful-booker.herokuapp.com',
    extraHTTPHeaders: { Accept: 'application/json' },
  },
});
